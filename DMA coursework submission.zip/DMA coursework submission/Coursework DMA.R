install.packages("dplyr")
library(dplyr)
install.packages("reshape2")
library(reshape2)
install.packages("ggplot2")
library(ggplot2)
install.packages("caret")
library(caret)
install.packages("randomForest")
library(randomForest)
install.packages("mlbench")
library(mlbench)
install.packages("e1071")
library(e1071)
install.packages("factoextra")
library(factoextra)
install.packages("ggfortify")
library(ggfortify)
install.packages("klaR")
library(klaR)
install.packages("caTools")
library(caTools)
install.packages("ISLR")
library(ISLR)
install.packages("MASS")
library(MASS)
install.packages("caret")
library(caret)

# rename breast.cancer.wisconsin to easier to refer to
bc = breast.cancer.wisconsin

# function
bc_removed_NA_Func = function(df){
  bc_NA <- replace(df, df == "?", NA)
  bc_removed_NA <- na.omit(bc_NA)
  return(bc_removed_NA)
}

bc_removed_NA_Func(bc)
nrow(bc_removed_NA)

# change ? to NA values
bc_NA <- replace(bc, bc == "?", NA)
bc_NA

# remove NA values
bc_removed_NA = na.omit(bc_NA)

# remove column 1 which contains the ID's as they aren't useful to us
bc_removed_NA = subset(bc_removed_NA, select = -c(V1))
bc_removed_NA

# rename 2 to benign and 4 to malignant
bc_removed_NA$V11[which(bc_removed_NA$V11 == "2")] <- "Benign"
bc_removed_NA$V11[which(bc_removed_NA$V11 == "4")] <- "Malignant"

#assigning correct column types
bc_removed_NA$V7 <- as.integer(as.character(bc_removed_NA$V7))
bc_removed_NA$V11 <- as.factor(as.character(bc_removed_NA$V11))

#pie chart of the dataset
Benign_total = sum(bc_removed_NA$V11 == "Benign")
Malig_total = sum(bc_removed_NA$V11 == "Malignant")

result <- c(Benign_total, Malig_total)
alabels <- round((result/sum(result)) * 100, 1)
alabels <- paste(alabels, "%", sep="")

colors <- c("blue", "red")
pie(table(bc_removed_NA$V11), col=c("blue","red"), labels = alabels, main = "Benign vs Malignant")
legend(0.7, 1.0, c("Benign", "Malignant"), fill=colors)

#pie chart of the training set
Benign_total1 = sum(bc_train$V11 == "Benign")
Malig_total1 = sum(bc_train$V11 == "Malignant")

result1 <- c(Benign_total1, Malig_total1)
alabels1 <- round((result1/sum(result1)) * 100, 1)
alabels1 <- paste(alabels1, "%", sep="")

colors <- c("blue", "red")
pie(table(bc_train$V11), col=c("blue","red"), labels = alabels1, main = "Benign vs Malignant")
legend(0.7, 1.0, c("Benign", "Malignant"), fill=colors)

#melts the data allowing us to create plots
bc_melt <- melt(bc_removed_NA, id.var = "V11")

#boxplots of data, as we can see V3 and V4 have a large amount of seperation indicating they would be good 
#for classification, V10 on the other hand would not be
bc_boxplot <- ggplot(data = bc_melt, aes(x=variable, y=value)) + 
  geom_boxplot(aes(fill=V11)) + ggtitle("Boxplots of variables grouped by type of growth")
bc_boxplot + facet_wrap( ~ variable, scales="free") + guides(fill=guide_legend(title="Classification"))

#gets the variance of each of the variables
sapply(bc_removed_NA[,1:9], var)
#range of nearly 10 therefore we must scale the data
range(sapply(bc_removed_NA[,1:9], var))

#scaling data (removed classifying column here)
bc_scaled <- as.data.frame(scale(bc_removed_NA[,1:9], center = FALSE))
#isolating the type column from old dataframe 
bc_type = bc_removed_NA[10]
#adding the old column to the new scaled df 
bc_scaled = cbind(bc_scaled, bc_type)
#variance of the scaled data
range(sapply(bc_scaled[,1:9], var))

#again melting the data so we can use it in a boxplot
bc_melt_scaled <- melt(bc_scaled, id.var = "V11")
#boxplot of scaled data
bc_scaled_boxplot <- ggplot(data = bc_melt_scaled, aes(x=variable, y=value)) + 
  geom_boxplot(aes(fill=V11)) + ggtitle("Boxplots of scaled variables grouped by type of growth")
bc_scaled_boxplot + facet_wrap( ~ variable, scales="free") + guides(fill=guide_legend(title="Classification"))

#writes to a csv file so we can produce a heatmap
write.csv(bc_scaled, "BreastCancerScaled.csv")

#histogram of scaled data, again V3 and V4 have a high degree of seperation between the classes,
#conversely, V10 has overlap 
bc_histogram = ggplot(data = melt(bc_scaled, id.var = "V11"), mapping = aes(x = value)) + 
  geom_histogram(bins = 20, aes(fill=V11), position = 'dodge') + facet_wrap(~variable, scales = 'free_x') +
  ggtitle("Histogram of variables grouped by type of growth")
bc_histogram

### HEATMAP USED TO DROP V4 AND V10, WE HAVE DONE THIS IN PYTHON, THE CODE SHALL BE ATTATCHED TO THE SUBMISSION ###

#drops columns V4 and V10, given to us by the heatmap and boxplots
bc_scaled_feature_selection <- subset(bc_scaled, select = -c(V4, V10))

#splitting the data into training and test data, set the seed to give reproducible results
set.seed(100)
#a third of our data is used for training
sample = floor(0.33 * nrow(bc_scaled_feature_selection))
train_ind = sample(seq_len(nrow(bc_scaled_feature_selection)), size = sample)

bc_train = bc_scaled_feature_selection[train_ind,]
bc_test = bc_scaled_feature_selection[-train_ind,]

#Analyse statistical differences between the training and the test partitions that you have created
summary(bc_train)
summary(bc_test)

############################# FEATURE SELECTION PEFORMED ON REDUCED DATASET (NO V4 OR V10 DUE TO HEATMAP CORRELATION) ########################################

# Feature selection type 1 (reduced feature elimination)
set.seed(100)
# define the control using a red function
control_random_forest <- rfeControl(functions=rfFuncs, method="cv", number=10)
# run the RFE algorithm
results <- rfe(bc_train[,1:7], bc_train[,8], sizes=c(1:7), rfeControl=control_random_forest)
# summarise the results, this tells us the accuracy of the features, 6 variables give the highest accuracy
print(results)
# list the chosen features, it gives "V3" "V2" "V9" "V7" "V6" "V8"
predictors(results)
# plot the results, rfe indicates 6 features should be used to give the best results 
plot(results, type=c("g", "o"))


#Feature selection type 2 (repeated cross validation)
set.seed(100)
# prepare training scheme for repeated cross validation
control = trainControl(method="repeatedcv", number=10, repeats=3)
# training the model
model = train(V11~., data=bc_train, method="lvq", preProcess="scale", trControl=control)
# estimate variable importance
importance <- varImp(model, scale=FALSE)
# summarise importance, V3 is the most important variable, V5 is the least important
print(importance)
# plot importance, here the 2 seperate methods (rfe and repeatedcv) give the same answer for the 
#most accurate features we should select
plot(importance)
#the plot shows V3, V6, and V7 are the top 3 most important features so we shall use them 
#as comparisons of our models

############ CREATING NAIVE BAYES MODEL FOR 3 VARIABLES #################

bc_train_model = subset(bc_train, select = c(V3,V6,V7, V11))

nbmodel = train(subset(bc_train_model, select = c(V3,V6,V7)), bc_train_model$V11, "nb", 
                trControl = trainControl(method = "cv", number = 10))

#testing the model on the test set
test_model = predict(nbmodel, bc_test)
#producing confusion matrix
confusion_matrix = confusionMatrix(test_model, bc_test$V11)

confusion_matrix #accuracy is 94.98
#f1 = 0.9675471862

############ CREATING NAIVE BAYES MODEL FOR 6 VARIABLES #################

rfe_bc_train_model = subset(bc_train, select = c(V9,V2,V7,V8,V6,V3,V11))

rfe_nbmodel = naiveBayes(V11~., data = rfe_bc_train_model)
#testing the model on the test set
rfe_nb_test_model = predict(rfe_nbmodel, bc_test)
#producing confusion matrix
rfe_nb_confusion_matrix = confusionMatrix(rfe_nb_test_model, bc_test$V11)
#accuracy is 96.07
rfe_nb_confusion_matrix 


############ CREATING LDA MODEL FOR 3 VARIABLES #################:

#creating the model
fs_ldamodel = train(V11~ V3 + V6 + V7, data = bc_train_model, method = "lda")
#the model:
feature_selection_ldamodel = predict(fs_ldamodel, bc_test)
#confusion matrix
fslda_confusion_matrix = confusionMatrix(feature_selection_ldamodel, bc_test$V11)
#gives 93.45 accuracy when using 3 features
fslda_confusion_matrix 

############ CREATING LDA MODEL FOR 6 VARIABLES #################:

#subsetting the training set into 6 variables
six_fs_bc_train = subset(bc_train, select = c(V2,V3,V6,V7,V8,V9, V11))
#training the model
six_fs_ldamodel = train(V11~ V2+V3+V6+V7+V8+V9, data = six_fs_bc_train, method = "lda")
#the model:
six_feature_selection_ldamodel = predict(six_fs_ldamodel, bc_test)
#confusion matrix
six_fslda_confusion_matrix = confusionMatrix(six_feature_selection_ldamodel, bc_test$V11)
#gives 95.2% accuracy when using 6 features
six_fslda_confusion_matrix 

######################## PCA ON ENTIRE DATASET (ALL FEATURES) ################

#doing PCA on the whole set
pca = prcomp(subset(bc_scaled, select = -c(V11)), scale = TRUE)
summary(pca)
#create a scree plot
scree_plot = fviz_eig(pca, addlabels = TRUE, linecolor = "Red", ylim = c(0, 75))
#Just a plot comparing the principal components
principal_components = autoplot(pca, data = bc_scaled, colour = 'V11')

#gets PCA from 1:7, removes 8 and 9 (because of scree plot)
pca_removed <- pca$x[,1:7]
#reassigning name
pca_combined <- pca_removed
pca_combined <- cbind(pca_removed, bc_scaled$V11)
pca_combined

# want to get malignant and benign back attached to this dataframe
N <- nrow(pca_combined)
N
#Creating training and testing sets again for PCA analysis and modelling using LDA
rvec <- runif(N)
rvec
#getting training sets and test sets 
pca_combined.train <- pca_combined[rvec < 0.33,]
pca_combined.test <- pca_combined[rvec >= 0.33,]

#reassigning variables into appropriate format
pca_combined.train.df <- pca_combined.train
pca_combined.train.df <- as.data.frame(pca_combined.train)
pca_combined.train.df

#################### CREATING LDA MODEL FOR PCA PREPROCESSING #######################

# model that we use to train the data
pca_combined.lda <- lda(pca_combined.train.df$V8 ~ PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7, data = pca_combined.train.df)
#reassigning variables
pca_combined.test.df <- pca_combined.test
pca_combined.test.df <- as.data.frame(pca_combined.test)
pca_combined.test.df
# predict how well your training data predicts the test data
pca_combined.test.predict <- predict(pca_combined.lda, newdata = pca_combined.test.df)
ls(pca_combined.test.predict)

pca_combined.test.predict$class
pca_combined.test.predict.class <- pca_combined.test.predict$class
pca_combined.test.predict.class

# compare accuracy of these predictions with the original data
confusionMat <- table(pca_combined.test.predict.class, pca_combined.test.df$V8)
#accuracy is 96.2%
confusionMat

########################## RUNNING NB AND LDA MODEL ON JUST HEATMAP FEATURE SELECTION (V2,V3,V5,V6,V7,V8,V9) ##########

################ NB MODEL #####################

nbmodel_heatmap = naiveBayes(V11~., data = bc_train)
test_model_heatmap = predict(nbmodel_heatmap, bc_test)
confusion_matrix_heatmap = confusionMatrix(test_model_heatmap, bc_test$V11)
#accuracy is 0.9607
confusion_matrix_heatmap

############### LDA MODEL #################

#training the model
seven_fs_ldamodel = train(V11~ V2+V3+V6+V7+V8+V9+V5, data = bc_train, method = "lda")
#the model:
seven_feature_selection_ldamodel = predict(seven_fs_ldamodel, bc_test)
#confusion matrix
seven_fslda_confusion_matrix = confusionMatrix(seven_feature_selection_ldamodel, bc_test$V11)
#gives 94.98% accuracy when using 6 features
seven_fslda_confusion_matrix

############### RUNNING RCV AND RFE ON ENTIRE DATASET (V2,V3,V4,V5,V6,V7,V8,V9,V10) ##########

#remaking our testing and training sets (same seed to give reproducible results)
bc_scaled
#splitting the data into training and test data, set the seed to give reproducible results
set.seed(100)
#a third of our data is used for training
sample_rfe_repeatedCV = floor(0.33 * nrow(bc_scaled))
train_ind_rfe = sample(seq_len(nrow(bc_scaled)), size = sample_rfe_repeatedCV)

bc_train_rfe = bc_scaled[train_ind_rfe,]
bc_test_rfe = bc_scaled[-train_ind_rfe,]

#Analyse statistical differences between the training and the test partitions that you have created
summary(bc_train_rfe)
summary(bc_test_rfe)

# RFE FEATURE SELECTION

set.seed(100)
# define the control using a random forest selection function
control_random_forest_rfe <- rfeControl(functions=rfFuncs, method="cv", number=10)
# run the RFE algorithm
results_rfe <- rfe(bc_train_rfe[,1:9], bc_train_rfe[,10], sizes=c(1:9), rfeControl=control_random_forest_rfe)
# summarise the results, this tells us the accuracy of the features, 8 variables give the highest accuracy
print(results_rfe)
# list the chosen features, it gives "V3" "V2" "V9" "V7" "V4 "V6" "V8" "V5"
predictors(results_rfe)
# plot the results, rfe indicates 8 features should be used to give the best results 
plot(results_rfe, type=c("g", "o"))

#REPEATED CV FEATURE SELECTION

set.seed(100)
# prepare training scheme for repeated cross validation
control_cv = trainControl(method="repeatedcv", number=10, repeats=3)
# training the model
model_cv = train(V11~., data=bc_train_rfe, method="lvq", preProcess="scale", trControl=control_cv)
# estimate variable importance
importance_cv <- varImp(model_cv, scale=FALSE)
# summarise importance, V3 is the most important variable, V10 is the least important
print(importance_cv)
# plot importance, here the 2 seperate methods (rfe and repeatedcv) give the same answer for the 
#most accurate features we should select
plot(importance_cv)
#the plot shows V3, V4, and V6 are the top 3 most important features so we shall use them 
#as comparisons of our models

################## LDA MODEL FOR 3 MOST IMPORTANT VARIABLES ##################
  
#creating the model
three_fs_bc_train_rfe = subset(bc_train_rfe, select = c(V3,V6,V4, V11))
fs_ldamodel_three = train(V11~ V3 + V4 + V6, data = three_fs_bc_train_rfe, method = "lda")
#the model:
feature_selection_ldamodel_three = predict(fs_ldamodel_three, bc_test_rfe)
#confusion matrix
fslda_confusion_matrix_three = confusionMatrix(feature_selection_ldamodel_three, bc_test_rfe$V11)
#gives 90.39 accuracy when using 3 features
fslda_confusion_matrix_three 

################## LDA MODEL FOR 6 MOST IMPORTANT VARIABLES ##################

#subsetting the training set into 6 variables
six_fs_bc_train_rfe = subset(bc_train_rfe, select = c(V3,V6,V4,V7,V2,V8, V11))
fs_ldamodel_six = train(V11~ V3 + V4 + V6 + V7 + V2 + V8, data = six_fs_bc_train_rfe, method = "lda")
#the model:
feature_selection_ldamodel_six = predict(fs_ldamodel_six, bc_test_rfe)
#confusion matrix
fslda_confusion_matrix_six = confusionMatrix(feature_selection_ldamodel_six, bc_test_rfe$V11)
#gives 95.20 accuracy when using 6 features
fslda_confusion_matrix_six

################## NB MODEL FOR 3 MOST IMPORTANT VARIABLES ##################

fs_nbmodel = naiveBayes(V11~., data = three_fs_bc_train_rfe)
fs_nbmofel_pred = predict(fs_nbmodel, bc_test_rfe)
fs_nbmofel_confusion_matrix = confusionMatrix(fs_nbmofel_pred, bc_test_rfe$V11)
#accuracy is 0.9476
fs_nbmofel_confusion_matrix

################## NB MODEL FOR 6 MOST IMPORTANT VARIABLES ##################
#rfetest is the training set 
rfetest = subset(bc_train_rfe, select = c(V2, V3, V4, V6, V7, V8, V11))
six_rfe_model = naiveBayes(V11~., data = rfetest)
six_rfe_nb_test_model = predict(six_rfe_model, bc_test_rfe)
six_rfe_nb_confusion_matrix = confusionMatrix(six_rfe_nb_test_model, bc_test_rfe$V11)
#accuracy of 96.72
six_rfe_nb_confusion_matrix
 
