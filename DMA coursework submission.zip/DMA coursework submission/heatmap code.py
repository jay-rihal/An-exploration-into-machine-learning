import seaborn as sns

import matplotlib.pyplot as plt

import numpy as np

import pandas as pd

df = pd.read_csv(r"C:\Users\jsrih\OneDrive\Documents\BreastCancerScaled.csv")
print(df.head(10))

df = df.drop('Unnamed: 0',axis=1)

# features_mean = ['V2','V3','V4','V5','V6', 'V7', 'V8','V9', 'V10', 'V11']
# plt.figure(figsize=(15,15))

# heat = sns.heatmap(df[features_mean].corr(), vmax=1, square=True, annot=True)

sns.set(style='ticks', color_codes=True)
plt.figure(figsize=(14, 12))
df['V11'] = df['V11'].map({'Benign':2,'Malignant':4})
sns.heatmap(df.astype(float).corr(), linewidths=0.1, square=True, linecolor='white', annot=True)
plt.show()